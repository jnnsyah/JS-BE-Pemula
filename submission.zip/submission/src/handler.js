const bookshelf = require("./bookshelf");

const addBookHandler = (req, h) => {
    const { name, year, author, summary, publisher, pageCount, readPage, reading } = request.payload;
    const id = nanoid(16);
    const finished = readPage > pageCount ? true : false;
    const insertedAt = new Date().toISOString();
    const updateAt = insertedAt;
  
    if(!name) {
        return h.response({
            status: 'fail',
            message: 'Gagal menambahkan buku. Mohon isi nama buku'
        }).code(400);
    }

    if(finished) {
        return h.response({
            status: "fail",
            message: "Gagal menambahkan buku. readPage tidak boleh lebih besar dari pageCount"
        }).code(400)
    }

    const newBook = {
      name, year, author, summary, publisher, pageCount, readPage, finished, reading, id, insertedAt, updateAt,
    };
  
    bookshelf.push(newBook);
  
    const isSuccess = bookshelf.filter((book) => book.id ===id).length > 0;
  
    if (isSuccess) {
        return h.response({
            status: 'fail',
            message: 'Buku gagal ditambahkan',
        }).code(500);
    }
    
    return h.response({
      status: 'success',
      message: 'Catatan berhasil ditambahkan',
      data: {
        bookId: id,
      },
    }).code(201);
};

const getAllBookshelfHandler = () => ({
    status: 'success',
    data: {
        bookshelf: bookshelf ?? [],
    },
});

const getBookByIdHandler = (request, h) => {
    const { id } = request.params;
    const book = bookshelf.filter((book) => book.id = id)[0];

    if (book === undefined) {
        return h.response({
            status: 'fail',
            message: 'Buku tidak ditemukan',
        }).code(404);
    }

    return h.response({
        status: 'success',
        data: {
            book
        }
    })
}

const updateBookByIdHandler = (request, h) => {
    const { id } = request.params;
    const { name, year, author, summary, publisher, pageCount, readPage, reading } = request.payload;
    const updateAt = new Date().toISOString();

    if(!name) {
        return h.response({
            status: 'fail',
            message: 'Gagal menambahkan buku. Mohon isi nama buku'
        }).code(400);
    }
    
    if(finished) {
        return h.response({
            status: "fail",
            message: "Gagal menambahkan buku. readPage tidak boleh lebih besar dari pageCount"
        }).code(400)
    }

    const index = bookshelf.findIndex((book) => book.id === id);

    if (index === -1) {
        return h.response({
          status: 'fail',
          message: 'Gagal memperbarui buku. Id tidak ditemukan',
        }).code(404);
    }

    bookshelf[index] = {
        ...bookshelf[index],
        name: name ?? bookshelf[index].name,
        year: year ?? bookshelf[index].year,
        author: author ?? bookshelf[index].author,
        summary: summary ?? bookshelf[index].summary,
        publisher: publisher ?? bookshelf[index].publisher,
        pageCount: pageCount ?? bookshelf[index].pageCount,
        readPage: readPage ?? bookshelf[index].readPage,
        reading: reading ?? bookshelf[index].reading,
        updateAt,
    };

    return h.response({
        status: 'success',
        message: 'Buku berhasil diperbarui'
    }).code(200);
}

const deleteBookByIdHandler = (request, h) => {
    const { id } = request.params;
    const index = bookshelf.findIndex((book) => book.id === id);

    if (index === -1) {
        return h.response({
            status: 'fail',
            message: 'Buku gagal dihapus. Id tidak ditemukan',
          }).code(404);
    }

    bookshelf.splice(index, 1);

    return h.response({
        status: 'success',
        message: 'Buku gagal dihapus. Id tidak ditemukan'
    }).code(200);
}

module.exports = { addBookHandler, getAllBookshelfHandler, getBookByIdHandler, updateBookByIdHandler, deleteBookByIdHandler };